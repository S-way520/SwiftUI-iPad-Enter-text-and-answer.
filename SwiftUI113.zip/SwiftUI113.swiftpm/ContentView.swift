import SwiftUI
struct ContentView: View {
    var body: some View {
        MyTextFieldView()
    }
}
struct MyTextFieldView: View {
    @State private var text = ""
    @State private var confirmedText = ""
    @State private var show1Alert = false
    @State private var show2Alert = false
    @State private var show3Alert = false
    var body: some View {
        if show1Alert {
            Text("You said \(text) Well, let's start today's story")
                .padding(60)
        }
        if show2Alert {
            Text("We don't have to go out anymore. Let's continue to tell the story.")
                .padding(60)   
        }
        if show3Alert {
            Text("Do you know 烟雨行舟？")
                .padding(60)
        }
        VStack {
            Spacer()
            Text("What color is the sky today?")
            HStack{
                TextField("Enter here", text: $text)
                    .textFieldStyle(.roundedBorder)
                Button(action: {confirmedText = text}, label: {
                    Image(systemName: "paperplane")
                })
                .onChange(of: confirmedText, perform: { value in
                    if confirmedText.contains("blue") {
                        show1Alert = true
                        show2Alert = false
                        show3Alert = false
                    } 
                    if confirmedText.contains("grey") {
                        show2Alert = true
                        show1Alert = false
                        show3Alert = false
                    }
                    if confirmedText.contains("raining") {
                        show3Alert = true
                        show1Alert = false
                        show2Alert = false
                    }
                })
            }
        }
        .padding()
    }
}
